#include "pcadetector.h"
#include "Global.h"
#include "QTime"


PCADetector::PCADetector(QObject *parent, PCAClassifier *_classifier)
: QThread(parent),
m_classifier(_classifier), 
m_threshold(DEFAULT_THRESHOLD), 
m_scanStep(DEFAULT_SCAN_STEP), 
m_scaleRate(DEFAULT_SCALE_RATE), 
m_groupOverlappingRects(DEFAULT_GROUP_RECTS)
{

}

PCADetector::~PCADetector()
{

}

const std::vector<cv::Rect>& PCADetector::results() const
{
	return m_resultRects;
}

cv::Mat PCADetector::faceDetectedAtIndex(int index) const
{
	if (!m_resultRects.size())
	{
		return cv::Mat::zeros(m_classifier->templateSize(), CV_8UC1);
	}

	return m_images[kSkinSegmentedImage](m_resultRects[index]);
}

const cv::Mat& PCADetector::image(ImageType type) const
{
	return m_images[type];
}

void PCADetector::setClassifier(PCAClassifier *_classifier)
{
	m_classifier = _classifier;
}

void PCADetector::importImage(const cv::Mat& image)
{
	m_images[kOriginalImage] = image;
}

void PCADetector::setThreshold(double threshold)
{
	m_threshold = threshold;
}

void PCADetector::setScanStep(int scanStep)
{
	m_scanStep = scanStep;
}

void PCADetector::setScaleRate(double scaleRate)
{
	m_scaleRate = scaleRate;
}

void PCADetector::setGroupRects(bool groupRects)
{
	m_groupOverlappingRects = groupRects;
}


// Constants for skin segmentation algorithms, may be variable as settings in the future
#define SKIN_SGMT_BLUR true
#define SKIN_SGMT_SMALL_CONTOUR_THRESHOLD 400
#define SKIN_SGMT_DILATION_SIZE 9
#define SKIN_SGMT_EROSION_SIZE 9
#define SKIN_SGMT_DILATION_TIMES 3
#define SKIN_SGMT_EROSION_TIMES 3
static const double SKIN_SGMT_PARAM_A = 25.39;
static const double SKIN_SGMT_PARAM_B = 14.03;
static const double SKIN_SGMT_PARAM_ECX = 1.60;
static const double SKIN_SGMT_PARAM_ECY = 2.41;
static const double SKIN_SGMT_PARAM_THETA = 2.53;
static const double SKIN_SGMT_PARAM_CX = 109.38;
static const double SKIN_SGMT_PARAM_CY = 152.02;
static const double SKIN_SGMT_PARAM_CGL = 85.0;
static const double SKIN_SGMT_PARAM_CGR = 135.0;
static const double SKIN_SGMT_PARAM_CRL = 260.0;
static const double SKIN_SGMT_PARAM_CRR = 280.0;
static const double SKIN_SGMT_PARAM_YL = 60.0;
static const cv::Mat SKIN_SGMT_ROTATION_MAT = (cv::Mat_<double>(2, 2) << cos(SKIN_SGMT_PARAM_THETA), sin(SKIN_SGMT_PARAM_THETA),
	-sin(SKIN_SGMT_PARAM_THETA), cos(SKIN_SGMT_PARAM_THETA));

void PCADetector::performSkinSegmentation()
{
	if (m_images[kOriginalImage].channels() == 1)
	{
		// If the original is grayscale, then skin segmentation is unavailable.
		m_images[kSkinSegmentedImage] = m_images[kOriginalImage];
		return;
	}

	int imgRows = m_images[kOriginalImage].rows;
	int imgCols = m_images[kOriginalImage].cols;
	int imgChannels = m_images[kOriginalImage].channels();
	cv::Mat binaryMask = cv::Mat::zeros(imgRows, imgCols, CV_8UC1);
	cv::Mat YCrCbImage;

	cv::cvtColor(m_images[kOriginalImage], YCrCbImage, CV_BGR2YCrCb);
	cv::cvtColor(m_images[kOriginalImage], m_images[kSkinSegmentedImage], CV_BGR2GRAY);

	// Blur the gray scale image if necessary
	if (SKIN_SGMT_BLUR)
	{
		GaussianBlur(m_images[kSkinSegmentedImage], m_images[kSkinSegmentedImage], cv::Size(3, 3), 1.0);
	}
	
	// Check each pixel to see if it matches the criteria of the color of skin
	for (int row = 0; row < imgRows; ++row)
	{
		const uchar *ptr_BGRData = m_images[kOriginalImage].ptr<uchar>(row);
		const uchar *ptr_YCrCbData = YCrCbImage.ptr<uchar>(row);
		uchar *ptr_MaskData = binaryMask.ptr<uchar>(row);

		for (int col = 0; col < imgCols; ++col)
		{
			double  R = ptr_BGRData[col * imgChannels + 2];
			double	G = ptr_BGRData[col * imgChannels + 1];
			double  B = ptr_BGRData[col * imgChannels];
			double  Y = ptr_YCrCbData[col * imgChannels];
			double Cr = ptr_YCrCbData[col * imgChannels + 1];
			double Cb = ptr_YCrCbData[col * imgChannels + 2];
			double Cg = 128.0 - 0.318 * R + 0.439 * G - 0.121 * B;

			cv::Mat modified_CrCb_Mat = SKIN_SGMT_ROTATION_MAT *
				(cv::Mat_<double>(2, 1) << Cb - SKIN_SGMT_PARAM_CX, Cr - SKIN_SGMT_PARAM_CY);
			double modCr = modified_CrCb_Mat.at<double>(0, 0);
			double modCb = modified_CrCb_Mat.at<double>(1, 0);

			if (Cr < SKIN_SGMT_PARAM_CRR - Cg &&
				Cr > SKIN_SGMT_PARAM_CRL - Cg &&
				Cg < SKIN_SGMT_PARAM_CGR      &&
				Cg > SKIN_SGMT_PARAM_CGL      &&
				 Y > SKIN_SGMT_PARAM_YL       &&
				 SQUARE((modCr - SKIN_SGMT_PARAM_ECX) / SKIN_SGMT_PARAM_A) +
				 SQUARE((modCb - SKIN_SGMT_PARAM_ECY) / SKIN_SGMT_PARAM_B) < 1)
			{
				ptr_MaskData[col] = 1;
			}
		}
	}

	// Perform morphological operations to improve the skin mask
	std::vector<std::vector<cv::Point>> contours;
	std::vector<cv::Vec4i> hierachy;

	// Remove small contours
	findContours(binaryMask.clone(), contours, hierachy, CV_RETR_CCOMP, CV_CHAIN_APPROX_SIMPLE);
	if (contours.size())
	{
		for (int idx = 0; idx >= 0; idx = hierachy[idx][0])
		{
			const std::vector<cv::Point> &contour = contours[idx];
			if (fabs(contourArea(cv::Mat(contour))) <= SKIN_SGMT_SMALL_CONTOUR_THRESHOLD)
			{
				drawContours(binaryMask, contours, idx, cv::Scalar(0), CV_FILLED, 8, hierachy);
			}
		}
	}

	// Apply dilation
	cv::Mat dilateKernel = cv::Mat::ones(SKIN_SGMT_DILATION_SIZE, SKIN_SGMT_DILATION_SIZE, CV_8UC1);
	dilate(binaryMask, binaryMask, dilateKernel, cv::Point(-1, -1), SKIN_SGMT_DILATION_TIMES);

	// Fill holes in contours
	contours.clear();
	hierachy.clear();
	findContours(binaryMask.clone(), contours, hierachy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE);
	if (contours.size())
	{
		for (int idx = 0; idx >= 0; idx = hierachy[idx][0])
		{
			drawContours(binaryMask, contours, idx, cv::Scalar(1), CV_FILLED, 8, hierachy);
		}
	}

	// Apply erosion
	cv::Mat erodeKernel = cv::Mat::ones(SKIN_SGMT_EROSION_SIZE, SKIN_SGMT_EROSION_SIZE, CV_8UC1);
	erode(binaryMask, binaryMask, erodeKernel, cv::Point(-1, -1), SKIN_SGMT_EROSION_TIMES);

	// Apply binary mask to grayscale image
	m_images[kSkinSegmentedImage] = m_images[kSkinSegmentedImage].mul(binaryMask);
}


void PCADetector::run()
{
	// Status check
	if (!m_classifier)
	{
		emit postMessage(tr("No available classifier."));
		return;
	}

	if (m_classifier->isEmpty())
	{
		emit postMessage(tr("PCA classifier not trained."));
		return;
	}

	if (m_images[kOriginalImage].empty())
	{
		emit postMessage(tr("Please import an image to proceed."));
		return;
	}

	// Perform face detection
	emit processStarted();
	QTime time;
	time.start();
	// First of all, perform skin segmentation on the imported image
	emit postMessage("Face detection started, perform skin segmentation first.");
	performSkinSegmentation();
	emit postMessage("Skin segmentation completed.");

	cv::Mat downsampledImage = m_images[kSkinSegmentedImage].clone();
	cv::Mat detectWindow;

	cv::Size windowSize = m_classifier->templateSize();

	double scale = 1.0;
	int imgCols = downsampledImage.cols;
	int imgRows = downsampledImage.rows;
	m_resultRects.clear();

	int iteration = 0;
	while (imgCols > windowSize.width && imgRows > windowSize.height)
	{
		iteration++;
		int results = 0;

		for (int row = 0; row < imgRows - windowSize.height; row += m_scanStep)
		{
			for (int col = 0; col < imgCols - windowSize.width; col += m_scanStep)
			{
				getRectSubPix(downsampledImage,
					windowSize,
					cv::Point2f(col + windowSize.width / 2.0,
					row + windowSize.height / 2.0),
					detectWindow);

				// Continue if detect window contains value of 0
				if (countNonZero(detectWindow) != windowSize.area())
				{
					continue;
				}

				equalizeHist(detectWindow, detectWindow);
				detectWindow.reshape(1, windowSize.area()).convertTo(detectWindow, CV_64FC1, 1 / 255.0);

				double distance = m_classifier->combinedDistance(detectWindow);
				if (distance < m_threshold)
				{
					downsampledImage(cv::Range(row, row + windowSize.height), cv::Range(col, col + windowSize.width)) = 0;

					// Marked as face candidate
					int x = col * scale;
					int y = row * scale;
					int width = windowSize.width * scale;
					int height = windowSize.height * scale;
					cv::Rect resultRect(x, y, width, height);
					m_resultRects.push_back(resultRect);

					results++;
				}
			}
		}
		emit postMessage(tr("Iteration %1 completed, %2 face candidates detected.").arg(iteration).arg(results));
		// Scale down the image for another iteration
		scale *= m_scaleRate;
		imgCols = m_images[kSkinSegmentedImage].cols / scale;
		imgRows = m_images[kSkinSegmentedImage].rows / scale;
		resize(m_images[kSkinSegmentedImage], downsampledImage, cv::Size(imgCols, imgRows));
	}

	// Group rectangles if necessary
	if (m_groupOverlappingRects)
	{
		emit postMessage("Grouping overlapping rectangles.");
		cv::groupRectangles(m_resultRects, 2, 0.6);
	}
	emit postMessage(tr("Face detection completed in %1s, %2 faces detected.").arg(time.elapsed() / 1000.0).arg(m_resultRects.size()));
	emit processFinished();
}