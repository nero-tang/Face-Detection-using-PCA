#ifndef PCADETECTOR_H
#define PCADETECTOR_H

#include <QThread>
#include "pcaclassifier.h"

class PCADetector : public QThread
{
	Q_OBJECT

public:
	PCADetector(QObject *parent = 0, PCAClassifier *_classifier = 0);
	~PCADetector();
	
	enum ImageType
	{
		kOriginalImage = 0,
		kSkinSegmentedImage,
		kImageTypeCount
	};

	const std::vector<cv::Rect>& results() const;
	cv::Mat faceDetectedAtIndex(int index) const;
	const cv::Mat& image(ImageType type) const;
	void setClassifier(PCAClassifier *_classifier);
	void importImage(const cv::Mat& image);

protected:
	void run();

private:
	PCAClassifier *m_classifier;
	double m_threshold;
#define DEFAULT_THRESHOLD 0.0
	int m_scanStep;
#define DEFAULT_SCAN_STEP 1
	double m_scaleRate;
#define DEFAULT_SCALE_RATE 1.2
	bool m_groupOverlappingRects;
#define DEFAULT_GROUP_RECTS true

	cv::Mat m_images[kImageTypeCount];
	std::vector<cv::Rect> m_resultRects;

	void performSkinSegmentation();

public slots:
	void setThreshold(double threshold);
	void setScanStep(int scanStep);
	void setScaleRate(double scaleRate);
	void setGroupRects(bool groupRects);

signals :
	void postMessage(const QString& msg);
	void processStarted();
	void processFinished();
};

#endif // PCADETECTOR_H
