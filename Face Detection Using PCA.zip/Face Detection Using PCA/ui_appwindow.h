#ifndef UI_APPWINDOW_H
#define UI_APPWINDOW_H

#include "QtWidgets"

class AppUI
{
public:
	enum FaceMarkingStyle
	{
		kFaceMarkingStyleRect = 0,
		kFaceMarkingStyleCircle,
		kFaceMarkingStyleCount
	};

	enum TreeWigetType
	{
		kFaceTemplateTreeWiget = 0,
		kNonfaceTemplateTreeWidget,
		kEigenfaceTreeWiget,
		kDetectResultTreeWidget
	};

	// Menu bar
	QMenuBar *menuBar;
	QAction *aboutAction;

	// Dock 
	QDockWidget *dockWidget;
	QListWidget *logList;

	// Status bar
	QStatusBar *statusBar;

	// Tool Bar
	QToolBar *toolBar;
	QAction *loadImageAct;
	QAction *loadFaceTempAct;
	QAction *loadNonfaceTempAct;
	QAction *zoomInAct;
	QAction *zoomOutAct;
	QAction *startTrainAct;
	QAction *startDetectAct;

	// Central widget
	QWidget *centralWidget;

	// Element Viewer
	QTabWidget *elemViewTab;
	QTreeWidget *faceTempTree;
	QTreeWidget *nonfaceTempTree;
	QTreeWidget *eigenfaceTree;
	QTreeWidget *detectResultTree;
	QLabel *meanfaceHolder;
	QLabel *elementHolder;

	// Image viewer
	QTabWidget *imageViewTab;
	QLabel *originalImageHolder;
	QLabel *skinSgmtImageHolder;
	QLabel *markedImageHolder;
	QScrollArea *originalImageScrArea;
	QScrollArea *skinSgmtImageScrArea;
	QScrollArea *markedImageSrcArea;
	qreal scaleFactor;

	// Settings area
	QGroupBox *settingsGroupBox;
	QSpinBox *princompSpinBox;
	QSpinBox *tempWidthSpinBox;
	QSpinBox *tempHeightSpinBox;
	QDoubleSpinBox *thresholdSpinBox;
	QDoubleSpinBox *scaleRateSpinBox;
	QSpinBox *scanStepSpinBox;
	QLabel *princompLabel;
	QLabel *tempWidthLabel;
	QLabel *tempHeightLabel;
	QLabel *thresholdLabel;
	QLabel *scaleRateLabel;
	QLabel *scanStepLabel;
	QCheckBox *groupRectCheckBox;
	QComboBox *markTypeComboBox;
	QLabel *markTypeLabel;

	// Progress bar
	QProgressBar *progressBar;

	void setup(QMainWindow *mainwindow)
	{
		// Menu Bar
		menuBar = new QMenuBar(mainwindow);
		mainwindow->setMenuBar(menuBar);

		aboutAction = new QAction("About", menuBar);
		menuBar->addAction(aboutAction);
		

		// Dock Widget
		dockWidget = new QDockWidget("Log", mainwindow);
		dockWidget->setAllowedAreas(Qt::BottomDockWidgetArea);

		mainwindow->addDockWidget(Qt::BottomDockWidgetArea, dockWidget);
		logList = new QListWidget(dockWidget);
		dockWidget->setWidget(logList);


		// Tool Bar
		toolBar = new QToolBar(mainwindow);
		mainwindow->addToolBar(toolBar);

		loadImageAct = toolBar->addAction(QIcon(":/File/images/My Pictures.png"), "Load an image for face detection");
		loadFaceTempAct = toolBar->addAction(QIcon(":/File/images/Folder Generic Green-01.png"), "Load face templates");
		loadNonfaceTempAct = toolBar->addAction(QIcon(":/File/images/Folder Generic Red-01.png"), "Load non-face templates");
		toolBar->addSeparator();
		zoomInAct = toolBar->addAction(QIcon(":/File/images/Zoom In-01.png"), "Zoom In");
		zoomOutAct = toolBar->addAction(QIcon(":/File/images/Zoom Out-01.png"), "Zoom Out");
		toolBar->addSeparator();
		startTrainAct = toolBar->addAction(QIcon(":/File/images/Button Play-01.png"), "Press to train PCA classifier");
		startDetectAct = toolBar->addAction(QIcon(":/File/images/Button Turn On-01.png"), "Press to start face detection");
		

		// Status bar
		statusBar = new QStatusBar(mainwindow);
		mainwindow->setStatusBar(statusBar);


		// Central widget
		centralWidget = new QWidget(mainwindow);
		mainwindow->setCentralWidget(centralWidget);


		// Element tree section
		elemViewTab = new QTabWidget(centralWidget);

		faceTempTree = new QTreeWidget(elemViewTab);
		faceTempTree->setColumnCount(3);
		faceTempTree->setHeaderLabels((QStringList() << "File" << "Size" << "Type"));
		elemViewTab->insertTab(0, faceTempTree, "Face");

		nonfaceTempTree = new QTreeWidget(elemViewTab);
		nonfaceTempTree->setColumnCount(3);
		nonfaceTempTree->setHeaderLabels((QStringList() << "File" << "Size" << "Type"));
		elemViewTab->insertTab(1, nonfaceTempTree, "Non-face");

		eigenfaceTree = new QTreeWidget(elemViewTab);
		eigenfaceTree->setColumnCount(2);
		eigenfaceTree->setHeaderLabels((QStringList() << "Index" << "Eigenvalue"));
		elemViewTab->insertTab(2, eigenfaceTree, "Eigenface");

		detectResultTree = new QTreeWidget(elemViewTab);
		detectResultTree->setColumnCount(3);
		detectResultTree->setHeaderLabels((QStringList() << "Index" << "Position" << "Size"));
		elemViewTab->insertTab(3, detectResultTree, "Result");

		meanfaceHolder = new QLabel(centralWidget);
		meanfaceHolder->setFixedSize(100, 100);
		meanfaceHolder->setPixmap(QPixmap(":/File/images/unknown.png").scaled(100, 100, Qt::KeepAspectRatio, Qt::SmoothTransformation));
		meanfaceHolder->setScaledContents(true);

		elementHolder = new QLabel(centralWidget);
		elementHolder->setFixedSize(100, 100);
		elementHolder->setPixmap(QPixmap(":/File/images/unknown.png").scaled(100, 100, Qt::KeepAspectRatio, Qt::SmoothTransformation));
		elementHolder->setScaledContents(true);

		QGridLayout *elemViewLayout = new QGridLayout;
		elemViewLayout->addWidget(elemViewTab, 0, 0, 1, 2);
		elemViewLayout->addWidget(meanfaceHolder, 1, 0, Qt::AlignCenter);
		elemViewLayout->addWidget(elementHolder, 1, 1, Qt::AlignCenter);

		/*
		* Image view section, displaying original image (imported by user), skin segmented image and image marked with faces detected
		*/
		imageViewTab = new QTabWidget(centralWidget);
		originalImageScrArea = new QScrollArea(imageViewTab);
		originalImageHolder = new QLabel(originalImageScrArea);
		originalImageHolder->setPixmap(QPixmap(":/File/images/unknown.png"));
		originalImageHolder->setAlignment(Qt::AlignCenter);
		originalImageScrArea->setWidget(originalImageHolder);
		originalImageScrArea->setWidgetResizable(true);
		imageViewTab->insertTab(0, originalImageScrArea, "Original Image");

		skinSgmtImageScrArea = new QScrollArea(imageViewTab);
		skinSgmtImageHolder = new QLabel(skinSgmtImageScrArea);
		skinSgmtImageHolder->setPixmap(QPixmap(":/File/images/unknown.png"));
		skinSgmtImageHolder->setAlignment(Qt::AlignCenter);
		skinSgmtImageScrArea->setWidget(skinSgmtImageHolder);
		skinSgmtImageScrArea->setWidgetResizable(true);
		imageViewTab->insertTab(1, skinSgmtImageScrArea, "Skin Mask");

		markedImageSrcArea = new QScrollArea(imageViewTab);
		markedImageHolder = new QLabel(markedImageSrcArea);
		markedImageHolder->setPixmap(QPixmap(":/File/images/unknown.png"));
		markedImageHolder->setAlignment(Qt::AlignCenter);
		markedImageSrcArea->setWidget(markedImageHolder);
		markedImageSrcArea->setWidgetResizable(true);
		imageViewTab->insertTab(2, markedImageSrcArea, "Detection Result");

		/* These widgets are settings for PCA training and detection
		* These values may have some constrains
		*/
		settingsGroupBox = new QGroupBox("Settings", centralWidget);
		tempWidthLabel = new QLabel("Template Width", settingsGroupBox);
		tempWidthSpinBox = new QSpinBox(settingsGroupBox);
		tempHeightLabel = new QLabel("Template Height", settingsGroupBox);
		tempHeightSpinBox = new QSpinBox(settingsGroupBox);
		princompLabel = new QLabel("Principal Components:", settingsGroupBox);
		princompSpinBox = new QSpinBox(settingsGroupBox);
		thresholdLabel = new QLabel("Detection Threshold:", settingsGroupBox);
		thresholdSpinBox = new QDoubleSpinBox(settingsGroupBox);
		scaleRateLabel = new QLabel("Scale Rate:", settingsGroupBox);
		scaleRateSpinBox = new QDoubleSpinBox(settingsGroupBox);
		scanStepLabel = new QLabel("Scan Step:", settingsGroupBox);
		scanStepSpinBox = new QSpinBox(settingsGroupBox);
		groupRectCheckBox = new QCheckBox("Group Rectangles", settingsGroupBox);
		markTypeLabel = new QLabel("Mark Type:", settingsGroupBox);
		markTypeComboBox = new QComboBox(settingsGroupBox);
		markTypeComboBox->addItems((QStringList() << "Rectangle" << "Circle"));

		QGridLayout *settingsLayout = new QGridLayout(settingsGroupBox);
		settingsLayout->addWidget(tempWidthLabel, 0, 0);
		settingsLayout->addWidget(tempWidthSpinBox, 0, 1);
		settingsLayout->addWidget(tempHeightLabel, 1, 0);
		settingsLayout->addWidget(tempHeightSpinBox, 1, 1);
		settingsLayout->addWidget(princompLabel, 2, 0);
		settingsLayout->addWidget(princompSpinBox, 2, 1);
		settingsLayout->addWidget(thresholdLabel, 3, 0);
		settingsLayout->addWidget(thresholdSpinBox, 3, 1);
		settingsLayout->addWidget(scaleRateLabel, 4, 0);
		settingsLayout->addWidget(scaleRateSpinBox, 4, 1);
		settingsLayout->addWidget(scanStepLabel, 5, 0);
		settingsLayout->addWidget(scanStepSpinBox, 5, 1);
		settingsLayout->addWidget(markTypeLabel, 6, 0);
		settingsLayout->addWidget(markTypeComboBox, 6, 1);
		settingsLayout->addWidget(groupRectCheckBox, 7, 0, 1, -1, Qt::AlignCenter);

		// Add progress bar
		progressBar = new QProgressBar(centralWidget);
		progressBar->setFixedHeight(30);
		progressBar->setSizePolicy(QSizePolicy::Minimum, QSizePolicy::Preferred);

		// Manage main widget layout
		QGridLayout *mainLayout = new QGridLayout(centralWidget);
		mainLayout->addLayout(elemViewLayout, 0, 0);
		mainLayout->addWidget(imageViewTab, 0, 1, -1, 1);
		mainLayout->addWidget(settingsGroupBox, 2, 0);
		mainLayout->addWidget(progressBar, 1, 0);

		mainwindow->setCentralWidget(centralWidget);
	}
};

#endif