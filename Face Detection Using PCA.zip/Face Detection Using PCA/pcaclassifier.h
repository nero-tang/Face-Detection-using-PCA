#ifndef PCACLASSIFIER_H
#define PCACLASSIFIER_H

#include <QThread>
#include "opencv2/opencv.hpp"

class PCAClassifier : public QThread
{
	Q_OBJECT

public:
	PCAClassifier(QObject *parent = 0);
	~PCAClassifier();

	enum TemplateType
	{
		kFaceTemplate = 0,
		kNonfaceTemplate,
		kTemplateTypeCount
	};

	bool isEmpty() const;
	double threshold() const;
	cv::Size templateSize() const;
	cv::Mat meanface() const;
	cv::Mat templateImage(int index, TemplateType type) const;
	std::vector<cv::Mat> eigenfaces() const;
	std::vector<double> eigenvalues() const;
	double combinedDistance(const cv::Mat& img) const;
	void setTemplates(const std::vector<cv::Mat>& vector, TemplateType type);
	void setTemplateSize(cv::Size tempSize);

public slots:
	void setPrincipleComponents(int princomps);

protected:
	void run();
	
private:
	cv::PCA *m_pca;
	cv::Mat m_templates[kTemplateTypeCount];
	int m_princomps;
#define DEFAULT_PRINCOMPS 1
	double m_threshold;
	cv::Size m_templateSize;
#define DEFAULT_TEMPLATE_WIDTH  19
#define DEFAULT_TEMPLATE_HEIGHT 19
	
	struct TrainingData
	{
		int templates;
		double avgDisntace;
		double weight;
		std::vector<bool> decisions;
		std::vector<double> distances;
		
		TrainingData(int _templates, bool _discision)
			: templates(_templates),
			avgDisntace(0.0),
			weight(0.5 / _templates),
			decisions(_templates, _discision),
			distances(_templates)
		{};
	};

signals:
	void postMessage(const QString& msg);
	void processStarted();
	void processFinished();
};



#endif // PCACLASSIFIER_H
