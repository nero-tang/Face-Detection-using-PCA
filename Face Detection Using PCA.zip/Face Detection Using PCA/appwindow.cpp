#include "appwindow.h"
#include "Global.h"

appWindow::appWindow(QWidget *parent)
: QMainWindow(parent), m_classifier(0), m_detector(0, &m_classifier)
{
	// Setup UI
	ui.setup(this);

	// Register custom qMetaType
	qRegisterMetaType< QList<QTreeWidgetItem *> >("QList<QTreeWidgetItem *>");

	// Apply value constrains for settings
	ui.tempWidthSpinBox->setMinimum(DEFAULT_TEMPLATE_WIDTH);
	ui.tempWidthSpinBox->setSuffix(tr(" pixels"));
	ui.tempHeightSpinBox->setMinimum(DEFAULT_TEMPLATE_HEIGHT);
	ui.tempHeightSpinBox->setSuffix(tr(" pixels"));
	ui.princompSpinBox->setMaximum(DEFAULT_TEMPLATE_WIDTH * DEFAULT_TEMPLATE_HEIGHT);
	ui.princompSpinBox->setMinimum(1);
	ui.thresholdSpinBox->setMinimum(DEFAULT_THRESHOLD);
	ui.thresholdSpinBox->setMaximum(100000);
	ui.thresholdSpinBox->setSingleStep(0.5);
	ui.scanStepSpinBox->setMinimum(1);
	ui.scaleRateSpinBox->setMinimum(1.1);
	ui.scaleRateSpinBox->setSingleStep(0.05);
	ui.groupRectCheckBox->setChecked(DEFAULT_GROUP_RECTS);

	// Setup signals & slots
	connect(&m_classifier, &PCAClassifier::postMessage, this, &appWindow::printMessage);
	connect(&m_classifier, &PCAClassifier::processStarted, this, &appWindow::busyProgressbar);
	connect(&m_classifier, &PCAClassifier::processFinished, this, &appWindow::onTrainingFinished);

	connect(&m_detector, &PCADetector::postMessage, this, &appWindow::printMessage);
	connect(&m_detector, &PCADetector::processStarted, this, &appWindow::busyProgressbar);
	connect(&m_detector, &PCADetector::processFinished, this, &appWindow::onDetectionFinshed);

	connect(&m_loader, &TemplateLoader::postMessage, this, &appWindow::printMessage);
	connect(&m_loader, &TemplateLoader::updateProgress, ui.progressBar, &QProgressBar::setValue);
	connect(&m_loader, &TemplateLoader::updateTemplateInfo, this, &appWindow::loadTemplateInfoList);

	connect(ui.faceTempTree, SIGNAL(itemClicked(QTreeWidgetItem*, int)), this, SLOT(displaySelectedTreeWidgetItem(QTreeWidgetItem*)));
	connect(ui.nonfaceTempTree, SIGNAL(itemClicked(QTreeWidgetItem*, int)), this, SLOT(displaySelectedTreeWidgetItem(QTreeWidgetItem*)));
	connect(ui.eigenfaceTree, SIGNAL(itemClicked(QTreeWidgetItem*, int)), this, SLOT(displaySelectedTreeWidgetItem(QTreeWidgetItem*)));
	connect(ui.detectResultTree, SIGNAL(itemClicked(QTreeWidgetItem*, int)), this, SLOT(displaySelectedTreeWidgetItem(QTreeWidgetItem*)));
	
	connect(ui.tempWidthSpinBox, SIGNAL(valueChanged(int)), this, SLOT(updateTemplateWidth(int)));
	connect(ui.tempHeightSpinBox, SIGNAL(valueChanged(int)), this, SLOT(updateTemplateHeight(int)));
	connect(ui.princompSpinBox, SIGNAL(valueChanged(int)), &m_classifier, SLOT(setPrincipleComponents(int)));
	connect(ui.thresholdSpinBox, SIGNAL(valueChanged(double)), &m_detector, SLOT(setThreshold(double)));
	connect(ui.scaleRateSpinBox, SIGNAL(valueChanged(double)), &m_detector, SLOT(setScaleRate(double)));
	connect(ui.scanStepSpinBox, SIGNAL(valueChanged(int)), &m_detector, SLOT(setScanStep(int)));
	connect(ui.groupRectCheckBox, SIGNAL(toggled(bool)), &m_detector, SLOT(setGroupRects(bool)));

	connect(ui.loadImageAct, &QAction::triggered, this, &appWindow::loadImage);
	connect(ui.loadFaceTempAct, &QAction::triggered, this, &appWindow::loadFaceTemplate);
	connect(ui.loadNonfaceTempAct, &QAction::triggered, this, &appWindow::loadNonFaceTemplate);
	connect(ui.startTrainAct, &QAction::triggered, this, &appWindow::performPCATraining);
	connect(ui.startDetectAct, &QAction::triggered, this, &appWindow::performFaceDetection);

	connect(ui.aboutAction, &QAction::triggered, this, &appWindow::showAbout);

	// Read Settings
	QSettings settings(tr("Archangel"), tr("Face Detection using PCA"));
	QSize size = settings.value("size").toSize();

	if (size.isValid())
	{
		printMessage(tr("Application initialized, settings loaded from %1").arg(settings.fileName()));
		resize(size);
		move(settings.value("pos").toPoint());
		ui.tempHeightSpinBox->setValue(settings.value("Template Height").toInt());
		ui.tempWidthSpinBox->setValue(settings.value("Template Width").toInt());
		ui.princompSpinBox->setValue(settings.value("Principal Components").toInt());
		ui.thresholdSpinBox->setValue(settings.value("Detection Threshold").toDouble());
		ui.scanStepSpinBox->setValue(settings.value("Scan Step").toInt());
		ui.scaleRateSpinBox->setValue(settings.value("Scale Rate").toDouble());
		ui.groupRectCheckBox->setChecked(settings.value("Group Rectangles?").toBool());
		ui.markTypeComboBox->setCurrentIndex(settings.value("Mark Type").toInt());
	}
	else
	{
		// handle first time usage.
		ui.tempHeightSpinBox->setValue(DEFAULT_TEMPLATE_HEIGHT);
		ui.tempWidthSpinBox->setValue(DEFAULT_TEMPLATE_WIDTH);
		ui.princompSpinBox->setValue(DEFAULT_PRINCOMPS);
		ui.thresholdSpinBox->setValue(DEFAULT_THRESHOLD);
		ui.scanStepSpinBox->setValue(DEFAULT_SCAN_STEP);
		ui.scaleRateSpinBox->setValue(DEFAULT_SCALE_RATE);
		ui.groupRectCheckBox->setChecked(DEFAULT_GROUP_RECTS);
	}
	
}

appWindow::~appWindow()
{
	// Saving Settings
	QSettings settings(tr("Archangel"), tr("Face Detection using PCA"));
	settings.setValue("size", size());
	settings.setValue("pos", pos());
	settings.setValue("Template Height", ui.tempHeightSpinBox->value());
	settings.setValue("Template Width", ui.tempWidthSpinBox->value());
	settings.setValue("Principal Components", ui.princompSpinBox->value());
	settings.setValue("Detection Threshold", ui.thresholdSpinBox->value());
	settings.setValue("Scan Step", ui.scanStepSpinBox->value());
	settings.setValue("Scale Rate", ui.scaleRateSpinBox->value());
	settings.setValue("Group Rectangles?", ui.groupRectCheckBox->isChecked());
	settings.setValue("Mark Type", ui.markTypeComboBox->currentIndex());
}

void appWindow::updateTemplateHeight(int height)
{
	cv::Size oldSize = m_classifier.templateSize();
	cv::Size newSize = cv::Size(oldSize.width, height);
	m_classifier.setTemplateSize(newSize);
}

void appWindow::updateTemplateWidth(int width)
{
	cv::Size oldSize = m_classifier.templateSize();
	cv::Size newSize = cv::Size(width, oldSize.height);
	m_classifier.setTemplateSize(newSize);
}

void appWindow::printMessage(const QString& msg)
{
	QDateTime time;
	QString logStr = time.currentDateTime().toString(" yyyy.MM.dd   HH:mm:ss    ");
	logStr.append(msg);
	ui.logList->addItem(logStr);
	ui.logList->scrollToItem(ui.logList->item(ui.logList->count() - 1));
}

void appWindow::loadImage()
{
	QStringList formats;
	foreach(QByteArray format, QImageReader::supportedImageFormats())
	if (format.toLower() == format)
	{
		formats.append("*." + format);
	}
	
	QString filename = QFileDialog::getOpenFileName(this, 
		tr("Please select an image"), QDir::currentPath(), 
		tr("Image files (%1)").arg(formats.join(' ')));

	if (filename.isEmpty())
	{
		return;
	}

	cv::Mat image = cv::imread(filename.toLocal8Bit().data());
	if (image.empty())
	{
		QMessageBox::warning(this, tr("Image Viewer"), tr("Cannot load file %1").arg(filename));
		return;
	}
	m_detector.importImage(image);
	ui.originalImageHolder->setPixmap(QPixmap::fromImage(Mat2QImage(image)));
	printMessage(tr("Image loaded from %1").arg(filename));
}

void appWindow::loadFaceTemplate()
{
	loadTemplates(PCAClassifier::kFaceTemplate);
}

void appWindow::loadNonFaceTemplate()
{
	loadTemplates(PCAClassifier::kNonfaceTemplate);
}

void appWindow::loadTemplates(PCAClassifier::TemplateType type)
{
	static const QStringList dialogTitle = QStringList() << "Import face templates" << "Import non-face templates";

	QString path = QFileDialog::getExistingDirectory(this, 
		dialogTitle.at(type), 
		QDir::currentPath(), 
		QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks);
	if (path.isEmpty())
	{
		return;
	}

	QDir dir(path);
	QFileInfoList fileInfoList = dir.entryInfoList(QDir::Files | QDir::NoSymLinks, QDir::Name);
	if (fileInfoList.isEmpty())
	{
		QMessageBox::warning(this, dialogTitle.at(type), tr("%1 is an empty folder.").arg(path));
		return;
	}

	ui.progressBar->setRange(0, fileInfoList.size());
	ui.progressBar->setValue(0);
	m_loader.loadTemplates(&m_classifier, fileInfoList, type);
}

void appWindow::onTrainingFinished()
{
	ui.thresholdSpinBox->setValue(m_classifier.threshold());
	ui.meanfaceHolder->setPixmap(QPixmap::fromImage(Mat2QImage(m_classifier.meanface())));
	QList<QTreeWidgetItem *> eigenfaceInfoList;
	int eigenfaces = m_classifier.eigenvalues().size();
	for (int i = 0; i < eigenfaces; ++i)
	{
		QStringList eigenfaceInfo = (QStringList() << QString::number(i)
			<< QString::number(m_classifier.eigenvalues()[i]));
		eigenfaceInfoList.append(new QTreeWidgetItem(eigenfaceInfo));
	}
	setTreeWigetInfoList(eigenfaceInfoList, AppUI::kEigenfaceTreeWiget);
	resetProgressbar();
}

void appWindow::onDetectionFinshed()
{
	ui.skinSgmtImageHolder->setPixmap(QPixmap::fromImage(Mat2QImage(m_detector.image(PCADetector::kSkinSegmentedImage))));
	cv::Mat markedImage = m_detector.image(PCADetector::kOriginalImage).clone();
	AppUI::FaceMarkingStyle markStyle = static_cast<AppUI::FaceMarkingStyle>(ui.markTypeComboBox->currentIndex());

	// Tree widget info list
	QList<QTreeWidgetItem *> resultInfoList;
	for (int i = 0; i < m_detector.results().size(); ++i)
	{
		cv::Rect rect = m_detector.results()[i];
		QStringList resultInfo = QStringList() << QString::number(i)
			<< tr("X: %1, Y: %2").arg(rect.x).arg(rect.y)
			<< tr("%1 x %2").arg(rect.width).arg(rect.height);
		resultInfoList.append(new QTreeWidgetItem(resultInfo));
		switch (markStyle)
		{
		case AppUI::kFaceMarkingStyleRect:
			rectangle(markedImage, rect, cv::Scalar(255, 255, 0), 1);
			break;
		case AppUI::kFaceMarkingStyleCircle:
		{
								 cv::Rect rect = m_detector.results()[i];
								 cv::Point center = cv::Point(rect.x + rect.width / 2, rect.y + rect.height / 2);
								 double radius = sqrt(rect.width*rect.height / 2.0);
								 circle(markedImage, center, radius, cv::Scalar(0, 0, 255), 1);
								 break;
		}

		}
	}
	setTreeWigetInfoList(resultInfoList, AppUI::kDetectResultTreeWidget);
	ui.markedImageHolder->setPixmap(QPixmap::fromImage(Mat2QImage(markedImage)));
	resetProgressbar();
}

void appWindow::loadTemplateInfoList(const QList<QTreeWidgetItem *>& templateInfos, PCAClassifier::TemplateType type)
{
	setTreeWigetInfoList(templateInfos, static_cast<AppUI::TreeWigetType>(type));
}

void appWindow::setTreeWigetInfoList(const QList<QTreeWidgetItem *>& templateInfos, AppUI::TreeWigetType type)
{
	ui.elemViewTab->setCurrentIndex(type);
	QTreeWidget *treeWiget = static_cast<QTreeWidget *>(ui.elemViewTab->currentWidget());
	treeWiget->clear();
	treeWiget->addTopLevelItems(templateInfos);
}

void appWindow::displaySelectedTreeWidgetItem(QTreeWidgetItem *selectedItem)
{
	AppUI::TreeWigetType type = static_cast<AppUI::TreeWigetType>(ui.elemViewTab->currentIndex());
	QTreeWidget *treeWidget = static_cast<QTreeWidget *>(ui.elemViewTab->currentWidget());
	int index = treeWidget->indexOfTopLevelItem(selectedItem);
	cv::Mat imageToBeDisplayed;
	switch (type)
	{
	case AppUI::kFaceTemplateTreeWiget:
	case AppUI::kNonfaceTemplateTreeWidget:
		imageToBeDisplayed = m_classifier.templateImage(index, static_cast<PCAClassifier::TemplateType>(type));
		break;
	case AppUI::kEigenfaceTreeWiget:
		imageToBeDisplayed = m_classifier.eigenfaces()[index];
		break;
	case AppUI::kDetectResultTreeWidget:
		imageToBeDisplayed = m_detector.faceDetectedAtIndex(index);
		break;
	default:
		imageToBeDisplayed = cv::Mat::zeros(m_classifier.templateSize(), CV_8UC1);
		break;
	}
	ui.elementHolder->setPixmap(QPixmap::fromImage(Mat2QImage(imageToBeDisplayed)));
}

void appWindow::performPCATraining()
{
	m_classifier.start(QThread::HighPriority);
}

void appWindow::performFaceDetection()
{
	m_detector.start(QThread::HighPriority);
}

void appWindow::busyProgressbar()
{
	ui.progressBar->setRange(0, 0);
	ui.startTrainAct->setEnabled(false);
	ui.startDetectAct->setEnabled(false);
}

void appWindow::resetProgressbar()
{
	ui.progressBar->setMaximum(1);
	ui.progressBar->reset();
	ui.startTrainAct->setEnabled(true);
	ui.startDetectAct->setEnabled(true);
}

void appWindow::showAbout()
{
	QMessageBox::about(this, "About", aboutProject());
}

