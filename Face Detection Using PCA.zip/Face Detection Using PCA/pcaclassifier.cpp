#include "pcaclassifier.h"
#include "QDebug"
#include "Global.h"
#include "QTime"

PCAClassifier::PCAClassifier(QObject *parent)
: QThread(parent),
m_pca(0), 
m_princomps(DEFAULT_PRINCOMPS), 
m_threshold(0.0), 
m_templateSize(DEFAULT_TEMPLATE_WIDTH, DEFAULT_TEMPLATE_HEIGHT)
{
	// Register Meta type
	qRegisterMetaType<PCAClassifier::TemplateType>("PCAClassifier::TemplateType");
}

PCAClassifier::~PCAClassifier()
{
	if (m_pca)
	{
		delete m_pca;
		m_pca = 0;
	}
}

bool PCAClassifier::isEmpty() const
{
	return m_pca == 0;
}

double PCAClassifier::threshold() const
{
	return m_threshold;
}

cv::Size PCAClassifier::templateSize() const
{
	return m_templateSize;
}

void PCAClassifier::setPrincipleComponents(int princomps)
{
	m_princomps = princomps > 0 ? princomps : 1;
}

cv::Mat PCAClassifier::templateImage(int index, TemplateType type) const
{
	if (m_templates[type].empty())
	{
		return cv::Mat::zeros(m_templateSize, CV_8UC1);
	}
	cv::Mat templateImage;
	m_templates[type].col(index).convertTo(templateImage, CV_8UC1, 255.0);
	return templateImage.reshape(1, m_templateSize.height);
}

void PCAClassifier::setTemplates(const std::vector<cv::Mat>& vector, TemplateType type)
{
	if (vector.empty())
	{
		return;
	}
	cv::Mat transMat = cv::Mat(m_templateSize.area(), vector.size(), CV_64FC1);

	for (int i = 0; i != vector.size(); ++i)
	{
		cv::Mat col_temp = transMat.col(i);
		vector[i].reshape(1, m_templateSize.area()).convertTo(col_temp, CV_64FC1, 1 / 255.0);
	}
	m_templates[type] = transMat;
}

void PCAClassifier::setTemplateSize(cv::Size tempSize)
{
	m_templateSize = tempSize;
	emit postMessage(tr("Template size: %1 x %2").arg(m_templateSize.width).arg(m_templateSize.height));
}

cv::Mat PCAClassifier::meanface() const
{
	cv::Mat meanface(m_templateSize.height, m_templateSize.width, CV_8UC1, cv::Scalar(0));
	if (!m_pca)
	{
		return meanface;
	}

	cv::normalize(m_pca->mean.reshape(1, m_templateSize.height), meanface, 0, 255, cv::NORM_MINMAX, CV_8UC1);
	return meanface;
}

std::vector<cv::Mat> PCAClassifier::eigenfaces() const
{
	std::vector<cv::Mat> eigenfaces;
	if (!m_pca)
	{
		return eigenfaces;
	}

	int princomps = m_pca->eigenvalues.rows;
	for (int i = 0; i < princomps; ++i)
	{
		cv::Mat eigenface(m_templateSize.height, m_templateSize.width, CV_8UC1);
		cv::normalize(m_pca->eigenvectors.row(i).reshape(1, m_templateSize.height), eigenface, 0, 255, cv::NORM_MINMAX, CV_8UC1);
		eigenfaces.push_back(eigenface);
	}
	return eigenfaces;
}

std::vector<double> PCAClassifier::eigenvalues() const
{
	std::vector<double> eigenvalues;
	if (!m_pca)
	{
		return eigenvalues;
	}

	int princomps = m_pca->eigenvalues.rows;
	for (int i = 0; i < princomps; ++i)
	{
		eigenvalues.push_back(m_pca->eigenvalues.at<double>(i, 0));
	}
	return eigenvalues;
}

double PCAClassifier::combinedDistance(const cv::Mat& img) const
{
	double distance = 0.0;
	if (!m_pca)
	{
		return distance;
	}

	if (img.empty())
	{
		return distance;
	}

	// Project image to PCA space then project back
	cv::Mat img_proj = m_pca->project(img);
	cv::Mat img_backproj = m_pca->backProject(img_proj);

	// Calculate combined distance
	double d2mf = norm(img - m_pca->mean);
	d2mf = SQUARE(d2mf);

	double dffs = norm(img - img_backproj);
	dffs = SQUARE(dffs);

	double difs = 0.0;
	int princomps = m_pca->eigenvalues.rows;
	for (int i = 0; i < princomps; ++i)
	{
		double tempVal = img_proj.at<double>(i, 0);
		tempVal = SQUARE(tempVal);
		tempVal /= m_pca->eigenvalues.at<double>(i, 0);
		difs += tempVal;
	}

	distance = 0.5 * (d2mf + dffs) / m_pca->eigenvalues.at<double>(princomps - 1, 0);

	return distance + difs;
}

#define SECTIONS   8
#define ITERATIONS 4
void PCAClassifier::run()
{
	// Status check
	if (m_templates[kFaceTemplate].empty() && m_templates[kNonfaceTemplate].empty())
	{
		emit postMessage(tr("Please import both face and non-face templates."));
		return;
	}
	else if (m_templates[kFaceTemplate].empty())
	{
		emit postMessage(tr("Please import face templates."));
		return;
	}
	else if (m_templates[kNonfaceTemplate].empty())
	{
		emit postMessage(tr("Please import non-face templates."));
		return;
	}

	// Perform classification
	emit processStarted();
	emit postMessage("PCA training started.");
	QTime time;
	time.start();

	if (m_pca)
	{
		delete m_pca;
	}
	m_pca = new cv::PCA(m_templates[kFaceTemplate], cv::Mat(), CV_PCA_DATA_AS_COL, m_princomps);
	emit postMessage(tr("Principal Components Analysis completed, face space dimension: %1").arg(m_pca->eigenvalues.rows));

	emit postMessage("Calculating classification threshold");
	// Calculate the intersection point of distance distribution
	TrainingData faces(m_templates[kFaceTemplate].cols, true);
	TrainingData nonfaces(m_templates[kNonfaceTemplate].cols, false);

	for (int i = 0; i < faces.templates; ++i)
	{
		double distance = combinedDistance(m_templates[kFaceTemplate].col(i));
		faces.distances[i] = distance;
		faces.avgDisntace += distance;
	}

	for (int i = 0; i < nonfaces.templates; ++i)
	{
		double distance = combinedDistance(m_templates[kNonfaceTemplate].col(i));
		nonfaces.distances[i] = distance;
		nonfaces.avgDisntace += distance;
	}

	faces.avgDisntace /= faces.templates;
	nonfaces.avgDisntace /= nonfaces.templates;

	double maxAvgDistance = std::max(faces.avgDisntace, nonfaces.avgDisntace);
	double minAvgDistance = std::min(faces.avgDisntace, nonfaces.avgDisntace);
	double searchIncrement = (maxAvgDistance - minAvgDistance) / (SECTIONS - 1);
	double bestError = 1.0;
	double bestThreshold = 0.0;

	// Begin iteration
	for (int i = 0; i < ITERATIONS; ++i)
	{
		for (int j = 0; j < SECTIONS; ++j)
		{
			double tempThreshold = minAvgDistance + j * searchIncrement;
			double tempError = 0.0;

			bool decision;

			for (int k = 0; k != faces.templates; ++k)
			{
				decision = (faces.distances[k] < tempThreshold) ? true : false;
				tempError = (faces.decisions[k] == decision) ? tempError : (tempError + faces.weight);
			}

			for (int k = 0; k != nonfaces.templates; ++k)
			{
				decision = (nonfaces.distances[k] < tempThreshold) ? true : false;
				tempError = (nonfaces.decisions[k] == decision) ? tempError : (tempError + nonfaces.weight);
			}

			tempError = (tempError > 0.5) ? (1.0 - tempError) : tempError;

			if (tempError < bestError)
			{
				bestError = tempError;
				bestThreshold = tempThreshold;
			}
		}

		double span = (maxAvgDistance - minAvgDistance) / SECTIONS;
		maxAvgDistance = bestThreshold + span;
		minAvgDistance = bestThreshold - span;
		searchIncrement = (maxAvgDistance - minAvgDistance) / (SECTIONS - 1);
	}
	m_threshold = bestThreshold;
	emit postMessage(tr("Classifier training completed in %1s, best threshold: %2, best error: %3").arg(time.elapsed() / 1000.0).arg(m_threshold).arg(bestError));
	emit processFinished();
}